

$.ready(
  $(".content").dblclick(function () {
      $(".map").show()
  }).click(function () {
      $(".map").hide()
    })
);

